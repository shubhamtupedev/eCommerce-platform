package com.ecommerce.commonlib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonLibApplicationTests {

	@Test
	void contextLoads() {
	}

}
